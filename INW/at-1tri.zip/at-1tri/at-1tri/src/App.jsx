import './App.css'
import Corpo from './Componentes/Corpo/Corpo'


function App() {
  
  return (
    <>
      <Corpo/>
    </>
  )
}

export default App
