export default function Corpo(){
    return(
        <main>
            <div className="mainContato">
                <div className="formaContato">
                    <h2>Dúvidas e </h2>
                    <h2>suporte, entre</h2>
                    <h2>em contato:</h2>
                    <div className="imagens">
                        <div className="imagem">
                            <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGYAAABmCAMAAAAOARRQAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAD/UExURQAAAHBw32tz72hw52h452V15GV16mpw5Gh052Z26Wlz5ml25mt26mhy52h152p16mZ06Gl05ml06Gl26Gp26Wh052l26Gl26mhz6Gh15mh16Wpz6Wp16Wp36Wh052l16Gl16Wl26Gh15ml06Gl16Gl06Gl16Gl26Wp16Gl16Gl26Gl06Wl16Wl16HJ+6XN96nyG6nyG64WO7IWP7I6X7Y6X7o6Y7Y+X7Y+X7peg75ig76Go8KGo8aGp8KGp8aqx8qqy8qux8rS687S69L3D9b7C9cbL9sfL9sfL99DU+NHU+Nnc+drc+drd+ePl++Pm++zu/PX2/vX3/vb2/v///0S/XO0AAAAtdFJOUwAQHyAgMDAwQFBQUF9gYG9wcHBwf4CPj5CQn5+fn6Cvr6+wv7/Pz8/P39/v7w3TuXgAAAAJcEhZcwAADsMAAA7DAcdvqGQAAARhSURBVGhDtZp9Y9M2EMbtJS0ehdBtFFboSiHZ1oS4IYNS6NpR0mVeoM28rN//s8yyHieWfNLJjvL7o/WLfE/udJIucgJnWp29g95gEAteD3ovn+xGIW55Ioye9F7n9jWOD3ZaaLMuYYeWKOjtelCKjqwakl4HrZuROQJDHP2D5i49cnBkRUOhqI/nXRk+xpM1aLmGq0y/bh/Vi9eKWpFr5IqkvwMbPFFDVySuPfQY7Zvy0ilwP6F1c/q8Tti8W1awOuExWq5Hfwv2aDypZEPV6o+PiElscXuKNj4w66ybySrHsKqzg/u+eAq7Kq26MzLLA1hW8JVkK6h089sxkh5sr2jhjl9+gPUlR7jhl6FWyXVw3TcHsA+8Z1lBBIGcTTmjZcHGnFHc2ZwzijvNnBmdTZJkcj7CqYnlGI1woRajyeJOkoyLK6TiHlSCZ7hAcIn/Fc4LEcEku/BmskjkLY1i7IQ4Jxjf/YUjjd8hAKbTefYXXukgCSwJcCk/aYUzaV3lM27qIAle4JTgS/Y05U8qDStcx6PzU9xXQNRwRvGPeH5eCUbmpM5/06uvixnua+RRs+WZ/NSpngi5epW5Ibf3hcyPOKEo7BU5KznBVQ2TStwXMraiKYGFu7Tcv+9wUeVv8zgVnYNDklInpJOlR6QMPWgk3wbBPRySnPwLIzmzS6lEypCJD74Pgvs4pJnASME8uXr321ucKNhkssVtD4cGxOh2wjQ4Bb8GwSEOSUbxmBqJFB/xCMWQqc7T2eW5YZDokBNAQRj8jCMSRwmBddn5JpA7Vwb+hA2eFE/QbFmHTXwKIzxf8ARNZJeJb2GF5QIP0HAyb5XxacGwpAFOJr6AGYZbNDfAysSfYciOPWaZjDXTBGOH/rHnmZNMlm8zroeu0dLEFvsd/WSRsvNNak8AMQtY5zSBQ8w4Z2L7Gp0zZnOa6xkxQ/NlOpvTXMjiLrN6Si7s/rAhE6WNpbRdYs1pQ3FWJqsFXDI6y+nEtIway6YSYtuLzQFwRoaOzeWMgajT3L6qjeilx8WX+JWQcemc1XcmFUsJWEJugnPzwJurr7CqsbBVMyXauYyxhHo/nUyTOe1Hxo1DtwiyUSNo47SKLZHTD2jEUrw4sETtdFmsq9w4ixQxC4JdnJOM/7jVw3Zz7RiunOW2Tci9Ezj9NL2dp4JZ8umDU3atWG1zMHX0WuRjU8K6swblN0ebc6fkzCbdUV+DbcodxZnMHafloD7FmClotAvFom11Zmxi63agO7OZsFGvQf2HLd9EqeA727QsW8Ktb/UgOkbit3u2YbVK26POQ9ikaHubdJb7tSTbnnTsKr7ixqn40bH1S0H7FzRuysCcYwquVTXNsWm8VOiskQj7NX6x1G46IQyUt0883zXKhDquSNrsV+wK3ZquSGoKDajVxYltd6FuYxFB+9Cpj5qFS6HDVQnd3dodT3P/0LTxOnzuS0MSRntH3SGMC4b9o/2O9YchzQlbkaRVy4cg+B/Qa0RbDy3AkAAAAABJRU5ErkJggg==" alt="twitter" width={40} height={40}/>
                        </div>
                        <div className="imagem">
                            <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGYAAABmCAMAAAAOARRQAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAADGUExURQAAAP///////////////////////////////////////////////////////////////////////////////////////wEcKhEqNxEqOCA4RCA4RSE4RCE4RTBHUTBHUjFHUkBVX0FVX1BjbFBjbVFjbFFjbWBxeWBxenB/h3B/iHCAh4CNlICNlYCOlJCboZCbopCcoZ+qr6Cpr6Cqr6CqsK+4vK+4vbC4vLC4vb/Gys/U18/U2N/j5N/j5eDj5O/x8v///zZhMqoAAAAXdFJOUwAQHyAwQFBfYG9wf4CPkJ+gr7C/z9/v9ND3xQAAAAlwSFlzAAAOwwAADsMBx2+oZAAABV5JREFUaEO1mm1j2jYQx2GYlDk8JDN23Q3WhmyZO2jGvCzZzKDw/b/UdKczSLJOlrH7exPJlvTPSafTg+l5M7gJJ/fzODkJkjiKJuFwQK+6IgjvsXmT5D4MqEhrhhOrREk8G1LBFvRvnRqSeNKu+4YRNVRLC5P8RYDoOqFBIxFg1rzr+rdUtxG3VNuXYUwVGxI38u8J1boCf4Oaj4rK3HOEgis7rMSv4955zMcaQmrKwVUeZlI7QJ2o1Op0pFKj05mKc3xuqEgnvKNGKwza+5hCwvj1oOV8MYn71LDOjF53RkQNa3xPLzvE4gYDetUlSTW8zekVx/FQFK+5zmtRFAd6b6XSbSN6YaV4fvjwnuVj9krlqhjd5vKy4oHa41k+H6mwQaJ7Gz/9j0/UlJvljsobjEkA4cf/8BO1U8sL1dDRzGGnTKmSPq3z/E2MuMFbvnn6URZhdBRzeGM+YgOrgrJ29hmWSq39ppgT0qMKL1j/C+V4dmjRA+V0LuawboZdVq8iDEKHtxqdkAgf/9GYjDIcRQ6tv0FRuznlppd1gF+g7p4yDL+JImvxFyeXdfZQKOhTtgr0xIrSDHL0hD1b+PsXPdUgJ2DjzH9Qc0MZBulkotAe/n6mpzojlGH77F+oaQzrMc/Aqz48bGXMRCNwyoDpj/jMZIYyrJ9hE9pkOD4rITQDoSOILmD8PonEz1jKBH0toEyVDTT2lTLAzog8z+LZfr36giMPPrCERBXYFbBzU8pQGvinshqAi5XAKDEysBzcU7rKZ2iJ0oIdqXzKNutVKtNgDwEyKaUNYHD4ZRO9iNLnKJrJwTrmMmJe4qVeWiMWMpS0oFfEXHpZKPcYVtPzjHTInFweoFc8QEZzb3Syy7wyuljju96QUhZA5jyoqKlHUZyR5+EwHUblxrXX0GRgZHB+KKABpYEumVFvTCkLqswRGjGDdQEP/6CMS2bcm1LKgiqDLVY2SuDipbZLZtq7o5QFVcYW304ncIIyjrlkZr4yOTRilSlXik5kcFGoLCfw0KfTvGXauYC3DPbPZcpLoICXQ/vLYCtqRKbAsKCMU2ZaN2/OFbHXtJ2ljKXnJ65gM3YsN7rM6XfIvf+TcqXKwit0hq5Dul5RRsrzQkDLtddCIGKaI0Izy9ryMcvk3lqLpSDDLGtileZ3aZVBlTtlFTVig8zZYQzETo0/p6GMuuXY6zrplp4jji3H3LkXwACjyohHF6E005cFkGG2qD84dzYYLs2oXMB2I11kW3O/DCNn3w7i2YNfPnF1rNncnsG5at/c4pmgz18IwT9oP0xUwT07c3IXKr0ef0+LB49K9LeDk9XsSIk8efCDgxHYzxw0hhkaeSJwzByckMrOkkVOXcZwurnhew1d2kOnQJVfKWdQXtw4oqe8R1m+2DudoNuWlDk+yj5z+hrFSzFC602e53TpUCKebNePaImAuyA633Y5NlFGfOFJ/6YaJvKsBjg2uKejXGfqWDBXQ4oxLicQ7FbUFE/KX1FcjHGbI9jnT3CytJOu1q4ZrN1DenyxORxo4FUOB6cP6sZ8mwtVxLhUdThbG6bUfEm/4yt1SWwY0/FniJIyACh8g27Tx1/SfbdVuwwIOv2uIrCqOCP1NbDfoxzb9uZoF906jlNIU+6oSSutPhOrwEaTp1/3fcWTuf4JokKf3+s2IKpREXQwTZ3jUtLa3xw+pjJqNU8TSyCz0+YLqO+vEpCrO85cYGq4zqB589/ajBoLJY6v6jyDZj2XjOsni53BnbdF14sAfb+ui8I2IkhQZ1Iyvf7XXBpByEXuJBp3pEEMw2mkmRVHszBo3Vd2BsEQCZrM9V6v9z/szjgpXIqG3wAAAABJRU5ErkJggg==" alt="instagram" width={40} height={40} />
                        </div>
                        <div className='imagem'>
                            <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGYAAABmCAMAAAAOARRQAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAADqUExURQAAAHBw32tz72hw52h452V15GV16mpw5Gh052Z26Wlz5ml25mhy52h152p16mZ06Gl06Gl26Gp26Wh052l26Gl26mhz6Gh15mh16Wpz6Wp16Wh052l16Gl16Wl26Gh15ml06Gl16Gl06Gl16Gl26Wp16Gl16Gl26Gl06Wl16Wl16HJ+6XN96nyG6nyG64WO7IWO7YWP7I6X7Y6X7o+X7Y+X7peg75ig76Go8KGo8aGp8KGp8aqx8rS687S69L3D9b7C9cbL9sfL9tDU+NHU+Nnc+drd+ePl++Pm++zu/PX2/vX3/vb2/v///+Q2tSIAAAAqdFJOUwAQHyAgMDAwQFBQUGBgb3BwcH+Aj4+QkJ+fn6Cvr6+wv7/Pz8/P39/v7zs9KkUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAARhSURBVGhDtZlhY9IwEIZbQcQpTrfpFN0EFbDdhjJUdIOJ3dxE5P//HZPmLU3bXJq26fNlTZrcu1wul5A6xrj3Owfd/mjkc0aDfnf/0X28soXbORDm0/QP2mhSmcZeH0bVHHdctCyPu6vXEHSrjcnd+whDeQw76FIccxFOSaFiIpwyQu0hOhfhuIHehrhH6FiUPRgwotRQBAPzAe2hSymGj2AlB9dkpegwclyjvMMinsOUBgsqLNXlpZ9W0cWiZqDXadhRydGx4jFBHyYVWFRhWRtGswzQwg5UXD/He1uoN6EO3lrDU+Uda0EWowqDqilGxTPYjnmCN1bJuM1qLMek3fYS9bZJRlsDtdYZQkBQ12CSUfAAdTXgSTm0vsH4fnyqqm1mOHGw1TkYKdjqWTMRx1Axzpmnn/AAzvBXTxQEb1DWcnYRrDabC5RCLjabu+BijBLNYyGDkoYvCybBWZ36Z2fnjE9sJFHd8hzNCEQQ7KBEMv8t7HHW+MuACmeVGGUa4bW8OPsCW1pmaKwkjLV3KBCMpf+a5p9uig6ZiotnigCGcrhFcxV8ctp4JpjBTC4at3lMZh/PBEYu47AgJLmXt2rY2jBlgS4K2MrRHzWMB8OigB7OvuNoz00FBqMbTjcn0P7AghH/0ClLz2niSckEBgyZoluGoT6eU2tmJaUazjo1cwG6ZciRkc2sr9gUT6Wa1VfW4lJuQntNKyP7bC2yyckdypuVqEjkItJrWpk5enOuUDdFefMDFXIjMta0MjfozfmMuq0jUfRPUObcoC6DVkYO520GhswKRd8X5RBycrQy6ByydftfVERrPhH0RCLwdOtmjL4h16jc5oVoHhJBv3VtkqEuC5yjr0CYncRLR8TAd5QERKj1dDktKbO5nZ3PlngOCViFdEzgEGeCt46jvmDmpGRMIGTYLk3vN/ZknjrOCzxmKSHzDV1TsKMNfbQtmJ85RAiwgxod0XJAB9MglZ4F62D2C48cdUB/4Oc0OtS+xWlxtRj70+UtSuBu+fX0dBHLhzlbQXhL9BoFFXKev+b/6mQ2XwSM5fxywpb8+DoWCXcKJQ+5zC4KSsZXWyFk/gQn27e0iO83uUzesTMaUZT5E2BfuJvTIjwHcHJvayb8p80ShRQ/2UCWxJwAtmo4Wq+BKbljXeo1GKHP8r1WEfisnjuumO3FgG5rq8wIIow6hyPd4Fq/5pRAAITQm05VEtfRtQ3HkwdT3+ywXzYyNQWbFGYCehOtQuYTpVtHFCg+R9TgtlFy/gX23ab8Zui+x1tbpKIsoml3eo5gNkMLDaygnBiBxWSgUcm9wDFHq2JNx2vBHoUVnZyxcCzMj4EKi7eqcT0wUam8fvjNphkV8o6Hy20jOmUH1DNzWERT9zuBxMM5tgAlZqir+3pPUtBzPfU3aAMKCJUX4bSN5sjbLzbzCpqdHowReL12qTnJ0OwcUd4bHlrSAK2dw17i24j37tXujlWJGLfVDmk1igg4zn9yz9DDvr26RAAAAABJRU5ErkJggg==" alt="discord" width={40} height={40} />
                        </div>
                    </div>
                </div>
                <div className="linha"></div>
                <div className="mainInfo">
                    <section id="contatoEmail">
                        <form>
                            <div className="caixas">
                                <div className="Nome">
                                    <label htmlFor="nome">Nome:</label>
                                    <input type="text" className="texto"></input>
                                </div>
                                <div className="Email">
                                    <label htmlFor="email">Email:</label>
                                    <input type="email" className="texto"></input>
                                </div>
                                <div className="Mensagem">
                                    <label htmlFor="email">Mensagem:</label>
                                    <input type="text" className="caixaMensagem"></input>
                                </div>
                            </div>
                            <div className="botao">
                                <button type="submit">Enviar</button>
                            </div>
                            
                        </form>
                    </section>
                </div>
            </div>
        </main>
    )
}